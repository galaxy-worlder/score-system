from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)

# 创建数据库和表
def init_db():
    conn = sqlite3.connect('sports_event.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    event TEXT,
                    score INTEGER,
                    points INTEGER)''')
    c.execute('''CREATE TABLE IF NOT EXISTS departments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    total_points INTEGER)''')
    conn.commit()
    conn.close()

# 清空成绩接口
@app.route('/reset_scores', methods=['POST'])
def reset_scores():
    # 连接数据库并清空成绩数据
    conn = sqlite3.connect('sports_event.db')
    c = conn.cursor()

    # 清空成绩表
    c.execute("DELETE FROM results")

    # 重置所有院系得分
    c.execute("UPDATE departments SET total_points = 0")

    conn.commit()
    conn.close()

    return jsonify({"message": "Scores and rankings have been reset."}), 200

# 成绩录入接口
@app.route('/add_score', methods=['POST'])
def add_score():
    data = request.json
    name = data['name']
    event = data['event']
    score = data['score']

    # 计算得分
    if score == 1:
        points = 5  # 金牌
    elif score == 2:
        points = 3  # 银牌
    elif score == 3:
        points = 1  # 铜牌
    else:
        return jsonify({"error": "Invalid score"}), 400

    # 插入数据到数据库
    conn = sqlite3.connect('sports_event.db')
    c = conn.cursor()
    c.execute("INSERT INTO results (name, event, score, points) VALUES (?, ?, ?, ?)", (name, event, score, points))
    conn.commit()

    # 更新院系得分
    department_name = data['department']
    c.execute("SELECT total_points FROM departments WHERE name=?", (department_name,))
    department = c.fetchone()
    if department:
        new_points = department[0] + points
        c.execute("UPDATE departments SET total_points=? WHERE name=?", (new_points, department_name))
    else:
        c.execute("INSERT INTO departments (name, total_points) VALUES (?, ?)", (department_name, points))

    conn.commit()
    conn.close()

    return jsonify({"message": "Score added successfully"}), 200

# 获取院系排行榜接口
@app.route('/get_ranking', methods=['GET'])
def get_ranking():
    conn = sqlite3.connect('sports_event.db')
    c = conn.cursor()
    c.execute("SELECT name, total_points FROM departments ORDER BY total_points DESC")
    departments = c.fetchall()
    conn.close()
    return jsonify(departments)

# 获取项目得分情况接口
@app.route('/get_project_scores', methods=['GET'])
def get_project_scores():
    conn = sqlite3.connect('sports_event.db')
    c = conn.cursor()

    # 获取每个项目的得分情况
    c.execute('''
        SELECT event, name, score, points FROM results 
        ORDER BY event, points DESC   
    ''')
    results = c.fetchall()

    # 格式化数据：按项目分类
    project_scores = {}
    for row in results:
        event, name, score, points = row
        if event not in project_scores:
            project_scores[event] = []
        project_scores[event].append({"name": name, "score": score, "points": points})

    conn.close()

    return jsonify(project_scores)

# 根路径处理
@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)

